// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.
// ----------------------------------------------------------------------------

var reportNumber = 0;

document.getElementById("reportSelect").onchange = function (e) {
    var log = document.getElementById("testing");
    //alert(this[this.selectedIndex].value);
    //alert(this.selectedIndex);
    reportNumber = Number(this.selectedIndex) + 1;
    //alert(reportNumber);
    log.innerHTML = this[this.selectedIndex].value;
    //console.log(reportLoadConfig);

    if (reportNumber == 1) {
        reportLoadConfig.accessToken = reportLoadConfig.accessToken1;
        reportLoadConfig.embedUrl = reportLoadConfig.embedUrl1;
        tokenExpiry = reportLoadConfig.TokenExpiry1;
    }
    else if (reportNumber == 2) {
        reportLoadConfig.accessToken = reportLoadConfig.accessToken2;
        reportLoadConfig.embedUrl = reportLoadConfig.embedUrl2;
        tokenExpiry = reportLoadConfig.TokenExpiry2;

    }
    else if (reportNumber == 3) {
        reportLoadConfig.accessToken = reportLoadConfig.accessToken3;
        reportLoadConfig.embedUrl = reportLoadConfig.embedUrl3;
        tokenExpiry = reportLoadConfig.TokenExpiry3;

    }
    else {
        reportLoadConfig.accessToken = reportLoadConfig.accessToken4;
        reportLoadConfig.embedUrl = reportLoadConfig.embedUrl4;
        tokenExpiry = reportLoadConfig.TokenExpiry4;

    }


    //$("#report-container").load(" #report-container > *");

    //function reload_js(src) {
    //    $('script[src="' + src + '"]').remove();
    //    $('<script>').attr('src', src).appendTo('head');
    //}

    //reload_js("lib/powerbi-client/dist/powerbi.min.js");

    //tokenExpiry = embedParams.EmbedToken.Expiration;

    // Embed Power BI report when Access token and Embed URL are available

    var reportContainer = $("#report-container").get(0);
    report = powerbi.embed(reportContainer, reportLoadConfig);

    // Clear any other loaded handler events
    report.off("loaded");

    // Triggers when a report schema is successfully loaded
    report.on("loaded", function () {
        console.log("Report load successful");
    });

    // Clear any other rendered handler events
    report.off("rendered");

    // Triggers when a report is successfully embedded in UI
    report.on("rendered", function () {
        console.log("Report render successful");
    });


    //console.log(reportLoadConfig);

    //alert("Reloaded!");
    //var models = window["powerbi-client"].models;
    //models.embedUrl = "google.com";
    //Embed.embedUrl = "google.com";
    //var powerbi-embed-url =/ "google.com";
    //log.appendChild(document.createElement("div")).appendChild(
    //   document.createTextNode("Changed to " + this[this.selectedIndex].text));
};

$(function () {
    var models = window["powerbi-client"].models;
    var reportContainer = $("#report-container").get(0);

    $.ajax({
        type: "GET",
        url: "/embedinfo/getembedinfo",
        success: function (data) {
            embedParams = $.parseJSON(data);
            //console.log(data);
            //console.log(embedParams);
            reportLoadConfig = {
                type: "report",
                tokenType: models.TokenType.Embed,
                accessToken: embedParams.EmbedToken[0].Token,
                accessToken1: embedParams.EmbedToken[0].Token,
                accessToken2: embedParams.EmbedToken[1].Token,
                accessToken3: embedParams.EmbedToken[2].Token,
                accessToken4: embedParams.EmbedToken[3].Token,
                // You can embed different reports as per your need
                //embedUrl: function () {
                //    return embedParams.EmbedReport[0].EmbedUrl
                //},
                embedUrl: embedParams.EmbedReport[0].EmbedUrl,
                embedUrl1: embedParams.EmbedReport[0].EmbedUrl,
                embedUrl2: embedParams.EmbedReport[0].EmbedUrl2,
                embedUrl3: embedParams.EmbedReport[0].EmbedUrl3,
                embedUrl4: embedParams.EmbedReport[0].EmbedUrl4,

                TokenExpiry1: embedParams.EmbedToken[0].Expiration,
                TokenExpiry2: embedParams.EmbedToken[1].Expiration,
                TokenExpiry3: embedParams.EmbedToken[2].Expiration,
                TokenExpiry4: embedParams.EmbedToken[3].Expiration,

                //Enable this setting to remove gray shoulders from embedded report
                settings: {
                    background: models.BackgroundType.Transparent
                }
            };

            // Use the token expiry to regenerate Embed token for seamless end user experience
            // Refer https://aka.ms/RefreshEmbedToken
            tokenExpiry = embedParams.EmbedToken.Expiration;

            // Embed Power BI report when Access token and Embed URL are available
            var report = powerbi.embed(reportContainer, reportLoadConfig);

            // Clear any other loaded handler events
            report.off("loaded");

            // Triggers when a report schema is successfully loaded
            report.on("loaded", function () {
                console.log("Report load successful");
            });

            // Clear any other rendered handler events
            report.off("rendered");

            // Triggers when a report is successfully embedded in UI
            report.on("rendered", function () {
                console.log("Report render successful");
            });



            // Clear any other error handler events
            report.off("error");
            
            // Handle embed errors
            report.on("error", function (event) {
                var errorMsg = event.detail;
            
                // Use errorMsg variable to log error in any destination of choice
                console.error(errorMsg);
                return;
            });
        },
        error: function (err) {
            
            // Show error container
            var errorContainer = $(".error-container");
            $(".embed-container").hide();
            errorContainer.show();
            
            // Format error message
            var errMessageHtml = "<strong> Error Details: </strong> <br/>" + err.responseText;
            errMessageHtml = errMessageHtml.split("\n").join("<br/>");

            // Show error message on UI
            errorContainer.append(errMessageHtml);
        }
    });
});